package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    SeekBar seekBar;
    TextView procencik_text;
    EditText kwota_rachunku;
    TextView napiwek;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        seekBar = findViewById(R.id.seekBar);
        procencik_text = findViewById(R.id.textView2);
        kwota_rachunku = findViewById(R.id.editTextNumberSigned);
        napiwek = findViewById(R.id.textView3);

        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener(){

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        procencik_text.setText( String.valueOf(progress));
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );

        kwota_rachunku.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                //napiwek.setText("Napiwek: " + String.valueOf(Double.parseDouble( procencik_text.getText() )));
                Double tmp = Double.parseDouble(kwota_rachunku.getText().toString())*0.01*Double.parseDouble(procencik_text.getText().toString());
                napiwek.setText(String.valueOf(tmp));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }
}

