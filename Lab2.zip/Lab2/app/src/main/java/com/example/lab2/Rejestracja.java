package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Rejestracja extends AppCompatActivity {

    EditText login;
    EditText password;
    EditText password_repeat;
    Button przycisk_rejestracji;

    SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String Name = "nameKey";
    public static final String Password = "passwordKey";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //musi byc setContent prosto po super
        setContentView(R.layout.activity_rejestracja);

        login = findViewById(R.id.LoginRID);
        password = findViewById(R.id.PasswordRID);
        password_repeat = findViewById(R.id.RepeatRID);
        przycisk_rejestracji = findViewById(R.id.RegisterButtonRID);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        przycisk_rejestracji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String na = login.getText().toString();
                String pa = password.getText().toString();
                String pare = password_repeat.getText().toString();

                SharedPreferences.Editor editor = sharedpreferences.edit();

                if (pa.equals(pare)) {
                    editor.putString(na, pa);
                    editor.apply();
                    Toast.makeText(Rejestracja.this, "Thanks for registering", Toast.LENGTH_LONG).show();
                    finish();
                }else {
                    Toast.makeText(Rejestracja.this, "Passwords need to match!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }



}