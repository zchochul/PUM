package com.example.lab2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText login;
    EditText password;
    Button przycisk_login;
    MenuItem rejestracja_przysk;
    MenuItem author;

    SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String Name = "nameKey";
    public static final String Password = "passwordKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = (EditText)findViewById(R.id.LoginID);
        password = (EditText)findViewById(R.id.PasswordID);
        przycisk_login = findViewById(R.id.button);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        przycisk_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences editor = getSharedPreferences(MyPREFERENCES, MODE_PRIVATE);
                String na = login.getText().toString();
                String pa = password.getText().toString();
                String papa = editor.getString(na, "Not in database");

                if(pa.equals(papa)){
                    Intent intentBA = new Intent(getBaseContext(), SignedIn.class);
                    startActivity(intentBA);
                    Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "Wrong password", Toast.LENGTH_LONG).show();
                }

            }
        });
        //textwatcher
        //settextcolor
        // implement the TextWatcher callback listener
       /* public TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
               // password.setTextColor(getResources().getColor(R.color.errorColor));
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        }*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.author:
                return true;
            case R.id.registration:
                Intent intentMA = new Intent(this, Rejestracja.class);
                startActivity(intentMA);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}